function evaluate()
{
    var x;
    var y;
    x ="document"
    document.write("<br> assigning value of x to y using eval function");
    y=eval(x);
    document.write("<br>typeof(x): ");
    document.write(typeof(x)+ "<br>");
    document.write("typeof(y): ");
    document.write(typeof(y)+ "<br>");
}