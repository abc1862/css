for(i=1;i<=10;i++)
{
    sq=i*i;
    if(i==9)
    {
        document.write("Skiping number: "+i+"<br>");
        continue;
    }
    document.write("Number: "+i+" Square: "+sq+"<br>");
}
a=100
document.write(a);
var a=10
// document.write(a);