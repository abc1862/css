var a;
a=10;
document.write(a);
a="Capgemini";
document.write(a);