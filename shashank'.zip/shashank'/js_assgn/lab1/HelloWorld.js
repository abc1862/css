function sayHello()
{
    document.write("This text is displayed by calling external function Hello World");
}