var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(v1,v2)
{

document.write(msg);

sum=v1+v2;
document.write("The sum of the variables headVar and bodyVar is" +sum);

}
