function dispHello()
{
    document.write("This text is displayed by calling external function: Hello World");
    
}